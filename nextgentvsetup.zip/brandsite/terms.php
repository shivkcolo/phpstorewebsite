<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'includes/head.php'; ?>
        <title><?php echo $brandName; ?></title>

</head>

<body>

    <?php include 'includes/navigation.php'; ?>
    <!-- Header Section -->
    <header class="jumbotron jumbotron-fluid text-center">
        <div class="container">
            <h1 class="display-4">Terms & Conditions</h1>
        </div>
    </header>

    <!-- Terms Section -->

    <section class="container my-5">
        <div class="row">
            <div class="col-md-12">
                <p>Welcome to <?php echo $brandName; ?>. By accessing or using our website, services, or making a purchase, you agree to be bound by the following terms and conditions. Please read them carefully before using our site.</p>

                <h5>1. Acceptance of Terms</h5>
                <p>By accessing or using our website, you confirm that you have read, understood, and agreed to these Terms and Conditions. If you do not agree with any part of these terms, you must not use our website or services.</p>

                <h5>2. Use of the Website</h5>
                <ul>
                    <li>You agree to use the website only for lawful purposes.</li>
                    <li>You must not misuse this website or attempt to hack, spam, or disrupt the site or any part of our service.</li>
                    <li>We reserve the right to restrict or terminate access if we believe a user is violating these terms.</li>
                </ul>

                <h5>3. Products and Services</h5>
                <ul>
                    <li>All products and services listed on our website are subject to availability.</li>
                    <li>We reserve the right to modify or discontinue any product or service without prior notice.</li>
                    <li>Prices and promotions are subject to change at any time.</li>
                </ul>

                <h5>4. User Accounts</h5>
                <ul>
                    <li>If you create an account with us, you are responsible for maintaining the confidentiality of your login details.</li>
                    <li>You agree to provide accurate and up-to-date information.</li>
                </ul>

                <h5>5. Payments</h5>
                <ul>
                    <li>All payments must be made in full at the time of purchase.</li>
                    <li>We accept major credit/debit cards and other secure payment methods.</li>
                    <li>Prices are listed in [your currency] and may include applicable taxes unless otherwise stated.</li>
                </ul>

                <h5>6. Returns and Refunds</h5>
                <p>Please refer to our Return and Refund Policy for information on returning products and receiving refunds.</p>

                <h5>7. Shipping</h5>
                <p>Details regarding processing times, shipping methods, and delivery timelines can be found in our Shipping Policy.</p>

                <h5>8. Intellectual Property</h5>
                <ul>
                    <li>All content on this website, including text, images, logos, and design elements, is the property of <?php echo $brandName; ?> and is protected by copyright laws.</li>
                    <li>You may not copy, distribute, or reproduce any content without written permission.</li>
                </ul>

                <h5>9. Limitation of Liability</h5>
                <ul>
                    <li>We are not responsible for any indirect, incidental, or consequential damages resulting from your use of our website or products.</li>
                    <li>Our liability is limited to the value of the product or service purchased.</li>
                </ul>

                <h5>10. Third-Party Links</h5>
                <p>Our website may contain links to third-party websites. We are not responsible for the content or practices of those sites and encourage you to review their terms.</p>

                <h5>11. Changes to Terms</h5>
                <p>We reserve the right to update or change these Terms and Conditions at any time. Changes will be posted on this page with an updated "Last Updated" date.</p>

                <h5>12. Governing Law</h5>
                <p>These terms are governed by and construed per the laws of [Your Country/State], and any disputes will be subject to the exclusive jurisdiction of the courts in that region.</p>

                <h5>13. Contact Us</h5>
                <p>If you have any questions about these Terms and Conditions, please contact us at: <br>
                    <strong>info@nextgentvsetup.com</strong>
                </p>
            </div>
        </div>
    </section>


    <?php include 'includes/footer.php'; ?>
</body>

</html>