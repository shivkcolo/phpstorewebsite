<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'includes/head.php'; ?>
        <title><?php echo $brandName; ?></title>

</head>

<body>

    <?php include 'includes/navigation.php'; ?>
    <!-- Header Section -->
    <header class="jumbotron jumbotron-fluid text-center">
        <div class="container">
            <h1 class="display-4">Shipping Policy</h1>
        </div>
    </header>


    <section class="container my-5">
        <div class="row">
            <div class="col-md-12">
                <p>At <?php echo $brandName; ?>, we are committed to delivering your orders quickly, safely, and efficiently. Please review our shipping policy to understand how and when your order will be delivered.</p>

                <h5>Processing Time</h5>
                <p>
                    All orders are processed within <strong>[1–3 business days]</strong> (excluding weekends and holidays) after receiving your order confirmation. You will receive a notification once your order has been shipped.<br>
                    <em>Please note: Processing time may be slightly extended during high-demand periods or promotional events.</em>
                </p>

                <h5>Shipping Confirmation & Tracking</h5>
                <p>
                    Once your order has shipped, you will receive a confirmation email with tracking details. You can use this to monitor your shipment in real time.
                </p>

                <h5>International Shipping</h5>
                <p>
                    We currently ship to select countries outside of the USA. International shipping fees and delivery times will vary depending on your location. Please be aware that you are responsible for any customs duties or taxes imposed by your country.
                </p>

                <h5>Shipping Restrictions</h5>
                <ul>
                    <li>We do not ship to P.O. Boxes or APO/FPO addresses.</li>
                    <li>Certain items may be restricted in some regions or countries due to legal or logistical constraints.</li>
                </ul>

                <h5>Lost or Damaged Packages</h5>
                <p>
                    We are not liable for any products damaged or lost during shipping. If your order arrives damaged or doesn’t arrive at all, please contact the shipping carrier first. Then reach out to our support team at <strong>[support email]</strong> with your order number and issue details — we’re here to help.
                </p>

                <h5>Need Assistance?</h5>
                <p>
                    For any shipping-related questions or concerns, feel free to contact our support team at <strong>info@nextgentvsetup.com</strong>. Your satisfaction is our priority.
                </p>
            </div>
        </div>
    </section>


    <?php include 'includes/footer.php'; ?>
</body>

</html>