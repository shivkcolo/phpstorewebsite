<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'includes/head.php'; ?>
    <title><?php echo $brandName; ?></title>
</head>

<body>

    <?php include 'includes/navigation.php'; ?>
    <!-- Header Section -->
    <header class="jumbotron jumbotron-fluid text-center">
        <div class="container">
            <h1 class="display-4">Return & Refund Policy</h1>
        </div>
    </header>


     <section class="container my-5">
        <div class="row">
            <div class="col-md-12">
                <p>At <?php echo isset($brandName) ? $brandName : '[Your Brand Name]'; ?>, we are committed to ensuring your satisfaction with every purchase. If you're not completely satisfied with your order, we’re here to help.</p>
                
                <h5>Returns</h5>
                <p>You may request a return within <strong>[7/14/30]</strong> days of receiving your product. To be eligible for a return:</p>
                <ul>
                    <li>The item must be unused and in the same condition that you received it.</li>
                    <li>It must be in the original packaging.</li>
                    <li>A receipt or proof of purchase is required.</li>
                </ul>
                <p>To initiate a return, please contact our support team at <strong>[your support email or contact form]</strong> with your order details. Once approved, we will provide return instructions.</p>
                
                <h5>Non-Returnable Items</h5>
                <p>Certain items are non-returnable, including:</p>
                <ul>
                    <li>Gift cards</li>
                    <li>Downloadable software products</li>
                    <li>Customized or personalized items</li>
                    <li>Items marked as “Final Sale”</li>
                </ul>
                
                <h5>Refunds</h5>
                <p>Once we receive and inspect your return, we will notify you of the status of your refund. If approved:</p>
                <ul>
                    <li>A refund will be processed to your original method of payment within <strong>[5–10 business days]</strong>.</li>
                    <li>Shipping charges (if applicable) are non-refundable.</li>
                </ul>
                
                <h5>Late or Missing Refunds</h5>
                <p>If you haven’t received your refund after the specified period:</p>
                <ul>
                    <li>Check your bank account again.</li>
                    <li>Contact your credit card company or bank—there may be a delay in posting.</li>
                    <li>If you’ve done all of this and still haven’t received your refund, please contact us at <strong>info@nextgentvsetup.com</strong>.</li>
                </ul>
                
                <h5>Exchanges</h5>
                <p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, contact us at <strong>info@brandname</strong> with your order number and photos (if applicable).</p>
                
                <h5>Shipping for Returns</h5>
                <p>You will be responsible for paying for your own shipping costs for returning your item unless the item is defective or incorrect.</p>
                
                <h5>Need Help?</h5>
                <p>For any questions related to returns or refunds, feel free to contact our customer service team at <strong>info@nextgentvsetup.com</strong>. We're here to make it right.</p>
            </div>
        </div>
    </section>


    <?php include 'includes/footer.php'; ?>
</body>

</html>