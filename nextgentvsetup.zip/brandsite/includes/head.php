<?php $brandName = "Next Gen TV Setup"; ?>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">

<style>
    body {
        padding-top: 56px;
    }

    .footer {
        background-color: #f8f9fa;
        padding: 20px 0;
    }
</style>