<!-- Footer -->
<footer class="footer border-top mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h5>About Us</h5>
                <p><?php echo $brandName; ?> is dedicated to making TV activation easy and hassle-free.</p>
            </div>
            <div class="col-md-3">
                <h5>Products</h5>
                <ul class="list-unstyled">
                    <li><a href="products.php">Computers & Tablet</a></li>
                    <li><a href="products.php">Printers & Accessories</a></li>
                    <li><a href="products.php">WiFi & Network Solutions</a></li>
                    <li><a href="products.php">Smart Home Devices</a></li>
                    <li><a href="products.php">Home Security Systems</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Support</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="contact-us.php">Contact Us</a></li>
                    <li><a href="privacy-policy.php">Privacy Policy</a></li>
                    <li><a href="terms.php">Terms & Conditions</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Contact Us</h5>
                <ul class="list-unstyled">
                    <li><i class="fas fa-envelope mr-2"></i>info@brnadname</li>
                </ul>
            </div>
        </div>
        <div class="text-center border-top mt-5 pt-3">
            <p>&copy; 2025 <?php echo $brandName; ?>. All rights reserved.</p>
        </div>
    </div>
</footer>

<script>
function addToCart(productId) {
    fetch('add_to_cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'product_id=' + productId
    })
    .then(response => response.text())
    .then(data => {
        alert('Added to cart!');
        // Optional: Update cart count without reloading
        document.getElementById('cart-count').innerText = data;
    });
}
</script>
<script>
    function addToCart(product) {
        window.location.href = 'cart-handler.php?action=add&product=' + encodeURIComponent(product);
    }

    function buyNow(product) {
        window.location.href = 'cart-handler.php?action=buy&product=' + encodeURIComponent(product);
    }
</script>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>